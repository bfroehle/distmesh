function p=pshift(p,x0,y0)

%   Copyright (C) 2004-2012 Per-Olof Persson. See COPYRIGHT.TXT for details.

p(:,1)=p(:,1)+x0;
p(:,2)=p(:,2)+y0;
